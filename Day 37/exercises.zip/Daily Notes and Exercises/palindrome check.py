from reverse_a_string import reverse_a_string

def is_palindrome(s):
    if s == reverse_a_string(s):
        return True
    else:
        return False

print(is_palindrome("racecar"))
print(is_palindrome("python"))
