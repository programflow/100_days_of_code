
def depth(l,c):
    if len(l) > 1:
        if type(l[0]) is not list:
            return depth(l[1:],c)
        else:
            return max(depth(l[0],c+1), depth(l[1:],c))
    elif len(l) == 1:
        if type(l[0]) is not list:
            print("got to here")
            return c+1
        else:
            return depth(l[0],c+1)
    else:
        return c+1


# def flatten(l):
#     if len(l) >1:
#         if type(l[0]) is not list:
#             return [l[0]] + flatten(l[1:])
#         else:
#             return flatten(l[0]) + flatten(l[1:])
#     else:
#         if type(l[0]) is not list:
#             return l
#         else:
#             return flatten(l[0])
#
# print(flatten([1, [2,[3,4]], 5,[5,6,[7,[8]]]])) # expected output: [1,2,3,4,5]
a = [1,[2],[3], 4, [3,[3,[4,[5]]]],1,2,3,[4]]
g = [1, [2,[3,4]], 5,[5,6,[7,[8]]]]
print(depth(a, 0))